@echo off
setlocal
cd /d "%~dp0"

echo.
echo ==========================================
echo Mewgenics《ty中文翻译》轻量汉化工具
echo ==========================================
echo.

if not exist "resources.gpak" (
  echo [错误] 当前目录没有找到 resources.gpak
  echo 请把这个轻量包放到游戏目录里再运行。
  pause
  exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 没有检测到 Python。
  echo 请先安装 Python 3，然后重新运行。
  pause
  exit /b 1
)

if exist "extracted_tyzh" rmdir /s /q "extracted_tyzh"
if exist "imported_tyzh" rmdir /s /q "imported_tyzh"

echo [1/3] 提取文本资源...
python "mewgenics_gpak.py" extract "resources.gpak" "extracted_tyzh" "data/text/combined.csv" "data/catnames_female_en.txt" "data/catnames_male_en.txt" "data/catnames_neutral_en.txt"
if errorlevel 1 (
  echo [错误] 提取失败。
  pause
  exit /b 1
)

echo [2/3] 导入 ty中文翻译数据...
python "mewgenics_import_ty_translation_csv.py" "mewgenics_ty_zh_translation_v17.csv" "extracted_tyzh" "imported_tyzh"
if errorlevel 1 (
  echo [错误] 导入翻译失败。
  pause
  exit /b 1
)

echo [3/3] 生成新的汉化资源包...
python "mewgenics_gpak.py" rebuild "resources.gpak" "imported_tyzh" "resources_ty中文翻译.gpak"
if errorlevel 1 (
  echo [错误] 回包失败。
  pause
  exit /b 1
)

echo.
echo 完成！
echo 已生成：
echo resources_ty中文翻译.gpak
echo.
echo 下一步：
echo 1. 先备份原 resources.gpak
echo 2. 把 resources_ty中文翻译.gpak 改名为 resources.gpak
echo 3. 启动游戏
echo.
pause
