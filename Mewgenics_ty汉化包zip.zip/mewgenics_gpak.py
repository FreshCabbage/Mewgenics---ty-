#!/usr/bin/env python3
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


MAGIC = b"NH\x00\x00"
MAX_NAME_LEN = 1024


@dataclass(frozen=True)
class Entry:
    path: str
    size: int
    offset: int


def _looks_like_path(text: str) -> bool:
    return ("/" in text or "." in text) and "\x00" not in text


def parse_gpak(archive: Path) -> tuple[list[Entry], int]:
    entries: list[tuple[str, int]] = []
    with archive.open("rb") as fh:
        if fh.read(4) != MAGIC:
            raise ValueError(f"{archive} is not a supported GPAK archive")

        index_end = 4
        while True:
            raw_len = fh.read(2)
            if len(raw_len) < 2:
                raise ValueError("unexpected EOF while reading index")
            name_len = int.from_bytes(raw_len, "little")
            if name_len <= 0 or name_len > MAX_NAME_LEN:
                fh.seek(-2, 1)
                break

            raw_name = fh.read(name_len)
            raw_size = fh.read(4)
            if len(raw_name) < name_len or len(raw_size) < 4:
                raise ValueError("unexpected EOF while reading index entry")

            try:
                name = raw_name.decode("utf-8")
            except UnicodeDecodeError:
                fh.seek(-(name_len + 4), 1)
                break

            if not _looks_like_path(name):
                fh.seek(-(name_len + 4), 1)
                break

            size = int.from_bytes(raw_size, "little")
            entries.append((name, size))
            index_end += 2 + name_len + 4

        data_start = fh.tell()

    offset = data_start
    parsed: list[Entry] = []
    for name, size in entries:
        parsed.append(Entry(path=name, size=size, offset=offset))
        offset += size
    return parsed, data_start


def iter_entries(entries: list[Entry], needles: Iterable[str]) -> Iterable[Entry]:
    wanted = list(needles)
    if not wanted:
        yield from entries
        return
    for entry in entries:
        if any(entry.path == needle or needle in entry.path for needle in wanted):
            yield entry


def list_entries(archive: Path, needles: list[str]) -> int:
    entries, data_start = parse_gpak(archive)
    print(f"archive={archive}")
    print(f"entries={len(entries)} data_start={data_start}")
    for entry in iter_entries(entries, needles):
        print(f"{entry.offset}\t{entry.size}\t{entry.path}")
    return 0


def extract_entries(archive: Path, out_dir: Path, needles: list[str]) -> int:
    entries, _ = parse_gpak(archive)
    out_dir.mkdir(parents=True, exist_ok=True)
    selected = list(iter_entries(entries, needles))
    if not selected:
        raise SystemExit("no matching entries")
    with archive.open("rb") as src:
        for entry in selected:
            dest = out_dir / entry.path
            dest.parent.mkdir(parents=True, exist_ok=True)
            src.seek(entry.offset)
            dest.write_bytes(src.read(entry.size))
            print(f"extracted {entry.path} -> {dest}")
    return 0


def rebuild_archive(archive: Path, patch_dir: Path, out_archive: Path) -> int:
    entries, data_start = parse_gpak(archive)
    out_archive.parent.mkdir(parents=True, exist_ok=True)

    header = bytearray(MAGIC)
    for entry in entries:
        replacement = patch_dir / entry.path
        size = replacement.stat().st_size if replacement.exists() else entry.size
        name = entry.path.encode("utf-8")
        header.extend(len(name).to_bytes(2, "little"))
        header.extend(name)
        header.extend(size.to_bytes(4, "little"))

    with archive.open("rb") as src, out_archive.open("wb") as dst:
        dst.write(header)
        for entry in entries:
            replacement = patch_dir / entry.path
            if replacement.exists():
                replacement_size = replacement.stat().st_size
                print(f"patching {entry.path} size={replacement_size}")
                with replacement.open("rb") as fh:
                    while True:
                        chunk = fh.read(1024 * 1024)
                        if not chunk:
                            break
                        dst.write(chunk)
                print(f"patched {entry.path}")
                continue

            src.seek(entry.offset)
            remaining = entry.size
            while remaining:
                chunk = src.read(min(1024 * 1024, remaining))
                if not chunk:
                    raise ValueError(f"unexpected EOF while copying {entry.path}")
                dst.write(chunk)
                remaining -= len(chunk)

    print(f"rebuilt archive -> {out_archive}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect and patch Mewgenics GPAK archives")
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list")
    list_parser.add_argument("archive", type=Path)
    list_parser.add_argument("needles", nargs="*")

    extract_parser = subparsers.add_parser("extract")
    extract_parser.add_argument("archive", type=Path)
    extract_parser.add_argument("out_dir", type=Path)
    extract_parser.add_argument("needles", nargs="*")

    rebuild_parser = subparsers.add_parser("rebuild")
    rebuild_parser.add_argument("archive", type=Path)
    rebuild_parser.add_argument("patch_dir", type=Path)
    rebuild_parser.add_argument("out_archive", type=Path)

    args = parser.parse_args()
    if args.command == "list":
        return list_entries(args.archive, args.needles)
    if args.command == "extract":
        return extract_entries(args.archive, args.out_dir, args.needles)
    return rebuild_archive(args.archive, args.patch_dir, args.out_archive)


if __name__ == "__main__":
    raise SystemExit(main())
