#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


NAME_FILES = {
    "data/catnames_female_en.txt": "catname_female",
    "data/catnames_male_en.txt": "catname_male",
    "data/catnames_neutral_en.txt": "catname_neutral",
}


def load_translation_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return [{k: (v or "") for k, v in row.items()} for row in reader]


def update_combined_csv(src_csv: Path, out_csv: Path, rows: list[dict[str, str]]) -> int:
    mapping = {}
    for row in rows:
        if row.get("entry_type") != "combined_csv":
            continue
        key = row.get("key", "").strip()
        if not key:
            continue
        preferred = (row.get("existing_zh") or "").strip() or (row.get("zh") or "").strip()
        if preferred:
            mapping[key] = preferred
    with src_csv.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = list(reader.fieldnames or [])
        data = list(reader)

    updated = 0
    for row in data:
        key = row["KEY"]
        if (row.get("zh") or "").strip():
            continue
        zh = mapping.get(key)
        if zh is not None:
            row["zh"] = zh
            updated += 1

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)
    return updated


def update_name_file(src_file: Path, out_file: Path, rows: list[dict[str, str]], rel_path: str) -> int:
    entry_type = NAME_FILES[rel_path]
    mapping = {}
    for row in rows:
        if row.get("entry_type") != entry_type:
            continue
        key = row.get("key", "").strip()
        if not key:
            continue
        preferred = (row.get("existing_zh") or "").strip() or (row.get("zh") or "").strip()
        if preferred:
            mapping[key] = preferred

    original_lines = src_file.read_text(encoding="utf-8").splitlines()
    new_lines: list[str] = []
    updated = 0
    for index, line in enumerate(original_lines, start=1):
        key = f"{entry_type.upper()}_{index:04d}"
        replacement = mapping.get(key)
        if replacement is not None:
            new_lines.append(replacement)
            updated += 1
        else:
            new_lines.append(line)

    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    return updated


def main() -> int:
    parser = argparse.ArgumentParser(description="Import translated Mewgenics export CSV back into patchable resource files")
    parser.add_argument("translated_csv", type=Path, help="Translated export CSV with zh column")
    parser.add_argument("src_root", type=Path, help="Extracted source root, e.g. work/mewgenics/extracted")
    parser.add_argument("out_root", type=Path, help="Patch root, e.g. work/mewgenics/imported_from_deepseek")
    parser.add_argument("--combined-src", type=Path, default=None, help="Optional combined.csv source to preserve existing curated zh")
    args = parser.parse_args()

    rows = load_translation_rows(args.translated_csv)
    combined_src = args.combined_src or (args.src_root / "data" / "text" / "combined.csv")
    combined_updated = update_combined_csv(
        src_csv=combined_src,
        out_csv=args.out_root / "data" / "text" / "combined.csv",
        rows=rows,
    )
    print(f"updated_combined={combined_updated}")

    total_name_updates = 0
    for rel_path in NAME_FILES:
        updated = update_name_file(
            src_file=args.src_root / rel_path,
            out_file=args.out_root / rel_path,
            rows=rows,
            rel_path=rel_path,
        )
        total_name_updates += updated
        print(f"updated_{rel_path}={updated}")

    print(f"wrote={args.out_root}")
    print(f"total_name_updates={total_name_updates}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
